import{L as n,D as g,E as m,P as l,T as D,M as d,Z as P,a as h}from"../../../assets/js/constants.d661545c.js";import{l as B,s as L}from"../../../assets/js/index.5b4a243d.js";const o=window.ZIPPYZIGGY={init(){console.log("ZP init"),localStorage.getItem(n)===null&&(this.targetLanguage=g),this.replaceFetch()},selectedPrompt:null,targetLanguage:localStorage.getItem(n)===null?g:localStorage.getItem(n),fetch:window._fetch=window._fetch||window.fetch,replaceFetch(){B.log("replace \uC2E4\uD589"),window.fetch=async(...a)=>{const[e,t]=a;if(e!==m)return this.fetch(e,t);if(!this.selectedPrompt&&!this.targetLanguage)return this.fetch(e,t);const r=this.selectedPrompt;try{const u=t,s=JSON.parse(u.body);if(r){const C=s.messages[0].content.parts[0],c=this.targetLanguage?this.targetLanguage:g,i=r.replaceAll(l,C).replaceAll(D,`

 Please write in ${c}`);s.messages[0].content.parts[0]=i,this.selectedPrompt=null}return!r&&this.targetLanguage&&(s.messages[0].content.parts[0]+=`

 Please write in ${this.targetLanguage}`),u.body=JSON.stringify(s),await this.fetch(e,u)}catch(u){return console.error("Error modifying request body",u),this.fetch(e,t)}}}};o.init();window.addEventListener("message",function(a){const{data:e}=a;switch(e.type){case"changeLanguage":{o.targetLanguage=L(a.data.targetLanguage),localStorage.setItem(n,o.targetLanguage);break}case"selectPrompt":{const{data:{prompt:t}}=a.data;o.selectedPrompt=t;break}case d:{const{data:{title:t,suffix:r,prefix:u,example:s,uuid:C}}=a.data,c=`\uD504\uB86C\uD504\uD2B8 \uC0C1\uC138 \uB9C1\uD06C ${h}/prompts/${C}

      \uD504\uB86C\uD504\uD2B8 \uC0C1\uC138 \uC815\uBCF4\uB294

 ${u||""} ${l} ${r||""} ${D}

 \uB2F5\uBCC0\uC740 \uC544\uB798\uC758 \uD615\uC2DD\uC5D0 \uB9DE\uCDB0\uC11C \uB2F5\uBCC0\uD574\uC918.
        1. [\u{1F517}\uD504\uB86C\uD504\uD2B8 \uC0C1\uC138\uC815\uBCF4](\uD504\uB86C\uD504\uD2B8 \uC0C1\uC138 \uB9C1\uD06C)\uB97C \uCCAB\uC904\uC5D0 \uCD9C\uB825
        2. \uACF5\uBC31 \uD55C\uC904 \uCD9C\uB825\uD6C4 \uB2F5\uBCC0\uC744 \uCD9C\uB825`.trim();o.selectedPrompt=c;const i=document.querySelector(`#${P}`);i.textContent=`\u{1F4DF} ${t}`;const p=document.querySelector("form textarea");p.placeholder=`\uC608\uC2DC) ${s}`;break}}});
