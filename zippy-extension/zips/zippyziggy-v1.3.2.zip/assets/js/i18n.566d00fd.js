const t=e=>chrome.i18n.getMessage(e);export{t};
