import{L as n,D as g,E as m,P as l,T as D,M as d,Z as P,a as h}from"../../../assets/js/constants.d661545c.js";import{s as L}from"../../../assets/js/index.d73e515b.js";const o=window.ZIPPYZIGGY={init(){console.log("ZP init"),localStorage.getItem(n)===null&&(this.targetLanguage=g),this.replaceFetch()},selectedPrompt:null,targetLanguage:localStorage.getItem(n)===null?g:localStorage.getItem(n),fetch:window._fetch=window._fetch||window.fetch,replaceFetch(){window.fetch=async(...u)=>{const[e,t]=u;if(e!==m)return this.fetch(e,t);if(!this.selectedPrompt&&!this.targetLanguage)return this.fetch(e,t);const r=this.selectedPrompt;try{const a=t,s=JSON.parse(a.body);if(r){const c=s.messages[0].content.parts[0],C=this.targetLanguage?this.targetLanguage:g,i=r.replaceAll(l,c).replaceAll(D,`

 Please write in ${C}`);s.messages[0].content.parts[0]=i,this.selectedPrompt=null}return!r&&this.targetLanguage&&(s.messages[0].content.parts[0]+=`

 Please write in ${this.targetLanguage}`),a.body=JSON.stringify(s),await this.fetch(e,a)}catch(a){return console.error("Error modifying request body",a),this.fetch(e,t)}}}};o.init();window.addEventListener("message",function(u){const{data:e}=u;switch(e.type){case"changeLanguage":{o.targetLanguage=L(u.data.targetLanguage),localStorage.setItem(n,o.targetLanguage);break}case"selectPrompt":{const{data:{prompt:t}}=u.data;o.selectedPrompt=t;break}case d:{const{data:{title:t,suffix:r,prefix:a,example:s,uuid:c}}=u.data,C=`\uD504\uB86C\uD504\uD2B8 \uC0C1\uC138 \uB9C1\uD06C ${h}/prompts/${c}

\uB2F5\uBCC0\uC740 \uC544\uB798\uC758 \uD615\uC2DD\uC5D0 \uB9DE\uCDB0\uC11C \uB2F5\uBCC0\uD574\uC918.
1. [\u{1F517}\uD504\uB86C\uD504\uD2B8 \uC0C1\uC138\uC815\uBCF4](\uD504\uB86C\uD504\uD2B8 \uC0C1\uC138 \uB9C1\uD06C)\uB97C \uCCAB\uC904\uC5D0 \uCD9C\uB825
2. \uACF5\uBC31 \uD55C\uC904 \uCD9C\uB825\uD6C4 \uB2F5\uBCC0\uC744 \uCD9C\uB825

${a||""} ${l} ${r||""}${D}`.trim();o.selectedPrompt=C;const i=document.querySelector(`#${P}`);i.textContent=`\u{1F4DF} ${t}`;const p=document.querySelector("form textarea");p.placeholder=`\uC608\uC2DC) ${s}`;break}}});
